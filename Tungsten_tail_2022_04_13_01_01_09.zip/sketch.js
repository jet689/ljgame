let entity;
let lvl = {};
function setup() {
  createCanvas(1000, 600);
  entity = new entity_();
  for (let i = 0; i <= round((width * height) / 60000); i++) {
    entity.newblock(width, random(0, height), 100, 20, random(1, 5));
  }
  entity.newcharacter(10, 1, 40, 50);
  entity.newblock(10, 300, 100, 20, 0.5);
  frameRate(60);
    if (windowHeight <= windowWidth) {
    document.getElementById("eb").style.zoom = "" + windowHeight / height-0.1;
  } else {
    document.getElementById("eb").style.zoom = "" + windowWidth / width-0.1;
  }
}

function draw() {
  background(220);

  entity.updateblocks();
  entity.charactercontact();
  entity.charactermove();
  entity.loadcharacter();
  entity.loadblocks();
  // console.log();
  console.log(keyCode);
  // entity.character[0]=10
  if (entity.character[1] >= height) {
    entity = new entity_();
    for (let i = 0; i <= round((width * height) / 60000); i++) {
      entity.newblock(width, random(0, height), 100, 20, random(1, 5));
    }
    entity.newcharacter(10, 1, 40, 50);
    entity.newblock(10, 300, 100, 20, 0.5);
  }

}
function lvl2() {}
function entity_() {
  this.block = [];
  this.character = [];
  this.precharacter = [];
  this.onblock = false;
  // makes a new array for the blocks info
  this.newblock = function (xplace, yplace, xsize, ysize, velocity) {
    splice(this.block, [[xplace, yplace, xsize, ysize, velocity]], 0);
  };
  //   shows the block/image/rectangle where ever it goes with whatever size
  this.loadblocks = function (img) {
    for (let i = 0; i <= this.block.length - 1; i++) {
      if (img) {
        image(
          img,
          this.block[i][0],
          this.block[i][1],
          this.block[0][2],
          this.block[0][3]
        );
      } else {
        rect(
          this.block[i][0],
          this.block[i][1],
          this.block[0][2],
          this.block[0][3]
        );
      }
    }
  };
  // moves blocks with their velocity
  this.updateblocks = function () {
    for (let i = this.block.length - 1; i >= 0; i--) {
      this.block[i][0] -= this.block[i][4];
      if (this.block[i][0] + this.block[i][2] <= 0) {
        this.block.splice(i, 1);
        entity.newblock(width, random(0, height), 100, 20, random(1, 5));
      }
    }
  };
  // gets character ready by getting x and y
  this.newcharacter = function (xstart, ystart, xsize, ysize) {
    this.character[0] = xstart;
    this.character[1] = ystart;
    this.character[2] = xsize;
    this.character[3] = ysize;
    this.character[4] = 0;
    this.character[5] = 0;
    this.character[6] = 0;
    this.character[7] = 0;
  };
  //shows character image/rectangle
  this.loadcharacter = function (img) {
    if (img) {
      image(
        img,
        this.character[0],
        this.character[1],
        this.character[2],
        this.character[3]
      );
    } else {
      rect(
        this.character[0],
        this.character[1],
        this.character[2],
        this.character[3]
      );
    }
  };
  // manages the movement of the character
  this.charactermove = function () {
    this.precharacter = this.character;

    if (this.onblock == true && keyIsPressed) {
      if (keyIsDown(68) || keyIsDown(39)) {
        this.character[0] += this.character[4];
        this.character[4] += 0.625 - this.character[4] / 8;
      }
      if (keyIsDown(65) || keyIsDown(37)) {
        this.character[0] += this.character[4];
        this.character[4] += -0.625 - this.character[4] / 8;
      }
      if (keyIsDown(32)||keyIsDown(38)) {
        this.character[1] += this.character[5];
        this.character[5] += -20 - this.character[5] / 4;
      }
    } else {
      if (keyIsDown(68) || keyIsDown(39)) {
        this.character[0] += this.character[4];
        this.character[4] += 0.625 - this.character[4] / 32;
      }
      if (keyIsDown(65) || keyIsDown(37)) {
        this.character[0] += this.character[4];
        this.character[4] += -0.625 - this.character[4] / 32;
      }
    }
    if (keyIsDown(65) || keyIsDown(37) || keyIsDown(68) || keyIsDown(39)) {
    } else {
      this.character[0] += this.character[4];
      this.character[4] += 0 - this.character[4] / 10;
      if (round(this.character[4] / 2) == 0) {
        this.character[4] = 0;
      }
    }
    this.character[1] += this.character[5];
    this.character[5] += 0.45 - this.character[5] / 20;
    // console.log(this.character[5])
  };
  //
  this.charactercontact = function () {
    this.onblock = false;
    for (let i = this.block.length - 1; i >= 0; i--) {
      if (
        (this.character[0] >= this.block[i][0] &&
          this.character[0] <= this.block[i][0] + this.block[i][2] &&
          this.character[1] + this.character[3] >= this.block[i][1] &&
          this.precharacter[1] + this.precharacter[3] <=
            this.block[i][1] + this.block[i][3]) ||
        (this.character[0] + this.character[2] >= this.block[i][0] &&
          this.character[0] + this.character[2] <=
            this.block[i][0] + this.block[i][2] &&
          this.character[1] + this.character[3] >= this.block[i][1] &&
          this.precharacter[1] + this.precharacter[3] <=
            this.block[i][1] + this.block[i][3])
      ) {
        this.character[5] = 0;
        this.character[1] = this.block[i][1] - this.character[3];

        this.onblock = true;
        // console.log("glitch");
      }
    }
  };
  /*
 
  console.log(this.block) */
}
function windowResized() {
    if (windowHeight <= windowWidth) {
    document.getElementById("eb").style.zoom = "" + windowHeight / height-0.1;
  } else {
    document.getElementById("eb").style.zoom = "" + windowWidth / width-0.1;
  }
}
